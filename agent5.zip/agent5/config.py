import os
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path("/opt/unsolved-channel")
AGENT1_DIR = BASE_DIR / "agent1"
DB_PATH = BASE_DIR / "data" / "cases.db"
LOG_PATH = BASE_DIR / "logs" / "agent5.log"
OUTPUT_DIR = BASE_DIR / "output" / "images"

load_dotenv(AGENT1_DIR / ".env")

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
IMAGE_MODEL = os.getenv("GEMINI_IMAGE_MODEL", "gemini-3.1-flash-image").strip()
IMAGE_SIZE = os.getenv("GEMINI_IMAGE_SIZE", "1K").strip()
ASPECT_RATIO = "16:9"

MAX_CASES_PER_RUN = 1
MAX_IMAGES_PER_RUN = 5
RETRY_LIMIT = 2
RETRY_DELAY_SECONDS = 12
